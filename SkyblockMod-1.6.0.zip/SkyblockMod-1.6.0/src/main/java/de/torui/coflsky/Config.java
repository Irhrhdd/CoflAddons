package de.torui.coflsky;

public class Config {
    public static final int KeepFlipsForSeconds = 42;
    public static String BaseUrl = "https://sky.coflnet.com";
}