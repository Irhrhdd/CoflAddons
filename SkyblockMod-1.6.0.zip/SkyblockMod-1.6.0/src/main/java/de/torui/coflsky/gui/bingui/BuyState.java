package de.torui.coflsky.gui.bingui;

public enum BuyState {
    INIT,
    PURCHASE,
    CONFIRM,
    BUYING
}
